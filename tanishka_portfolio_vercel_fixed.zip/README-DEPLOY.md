# Tanishka Portfolio — deployment

## Deploy with Vercel
1. Extract this ZIP. The `index.html`, `style.css`, `script.js`, `vercel.json`, and `api/` folder must be at the project root (not nested inside another folder).
2. Import the extracted project into a GitHub repository, or replace the files in the repository already connected to Vercel. Do not upload `.env.local`.
3. In Vercel, open Project → Settings → Build and Deployment. Set Root Directory to `.` / the repository root containing `index.html`. For this plain HTML project, use Framework Preset `Other`; leave Build Command and Output Directory empty unless your project uses a custom build.
4. In Vercel → Project → Settings → Environment Variables, add `GROQ_API_KEY` and set its value to your Groq API key. Optionally add `GROQ_MODEL` with value `openai/gpt-oss-20b`. Apply to Production (and Preview if needed).
5. Redeploy the latest commit. After deployment, test `/`, `/style.css`, `/script.js`, and `/api/chat` (the last should return Method not allowed for a GET; that is expected).

## Secret safety
`.env.local` is intentionally not included. Never commit API keys to GitHub or place them in HTML/JS. If a key was pushed publicly, revoke it and create a new one.
