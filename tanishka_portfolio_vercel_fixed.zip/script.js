// Handles the mobile menu and the light/dark theme toggle.
const navToggle = document.querySelector(".nav-toggle");
const primaryNav = document.querySelector("#primary-nav");
const navLinks = document.querySelectorAll("#primary-nav a");
const themeToggle = document.querySelector("#theme-toggle");
const THEME_KEY = "portfolio-theme";

function setMenuState(isOpen) {
  primaryNav.classList.toggle("is-open", isOpen);
  navToggle.setAttribute("aria-expanded", String(isOpen));
  navToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
}

if (navToggle && primaryNav) {
  navToggle.addEventListener("click", () => {
    const isOpen = !primaryNav.classList.contains("is-open");
    setMenuState(isOpen);
  });

  // Close the menu after a section link is chosen.
  navLinks.forEach((link) => {
    link.addEventListener("click", () => setMenuState(false));
  });
}

function getSavedTheme() {
  try {
    const savedTheme = localStorage.getItem(THEME_KEY);
    if (savedTheme === "light" || savedTheme === "dark") {
      return savedTheme;
    }
  } catch (error) {
    // localStorage can be blocked in some browsers.
  }
  return "dark";
}

function updateThemeButton(theme) {
  if (!themeToggle) {
    return;
  }

  const isDark = theme === "dark";
  const nextTheme = isDark ? "light" : "dark";
  const label = themeToggle.querySelector(".theme-toggle-text");

  themeToggle.setAttribute("aria-pressed", String(isDark));
  themeToggle.setAttribute("aria-label", "Switch to " + nextTheme + " mode");

  if (label) {
    label.textContent = isDark ? "Light" : "Dark";
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);

  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (error) {
    // The theme still changes for this visit even if saving fails.
  }

  updateThemeButton(theme);
}

applyTheme(getSavedTheme());

if (themeToggle) {
  themeToggle.addEventListener("click", () => {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    const nextTheme = currentTheme === "light" ? "dark" : "light";
    applyTheme(nextTheme);
  });
}

/* =========================
   AI CHATBOT
   ========================= */

const chatForm = document.querySelector("#chat-form");
const chatInput = document.querySelector("#chat-input");
const chatMessages = document.querySelector("#chat-messages");
const chatStatus = document.querySelector("#chat-status");
const chatSend = document.querySelector("#chat-send");

function addChatMessage(message, sender) {
  const messageElement = document.createElement("p");

  messageElement.classList.add("chat-message");
  messageElement.classList.add(
    sender === "user" ? "user-message" : "assistant-message"
  );

  // textContent displays text safely instead of interpreting HTML.
  messageElement.textContent = message;

  chatMessages.appendChild(messageElement);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

if (
  chatForm &&
  chatInput &&
  chatMessages &&
  chatStatus &&
  chatSend
) {
  chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const userMessage = chatInput.value.trim();

    if (!userMessage) {
      chatStatus.textContent = "Please enter a message.";
      return;
    }

    addChatMessage(userMessage, "user");
    chatInput.value = "";
    chatSend.disabled = true;
    chatStatus.textContent = "AI is thinking...";

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: userMessage
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "The AI service is unavailable."
        );
      }

      if (typeof data.reply !== "string" || !data.reply.trim()) {
        throw new Error("The AI returned an empty response.");
      }

      addChatMessage(data.reply, "assistant");
      chatStatus.textContent = "AI assistant ready";
    } catch (error) {
      addChatMessage(
        error.message || "Something went wrong. Please try again.",
        "assistant"
      );

      chatStatus.textContent =
        "Message failed. Please try again.";
    } finally {
      chatSend.disabled = false;
      chatInput.focus();
    }
  });
}

// Search and category filters for the skills section.
const skillCards = Array.from(document.querySelectorAll(".skill-card"));
const filterButtons = Array.from(document.querySelectorAll(".filter-btn"));
const technologySearch = document.querySelector("#technologySearch");
const technologyResults = document.querySelector("#technologyResults");
let activeSkillFilter = "all";

function updateSkillResults() {
  const query = (technologySearch?.value || "").trim().toLowerCase();
  let visibleCount = 0;
  skillCards.forEach((card) => {
    const categoryMatches = activeSkillFilter === "all" || card.dataset.category === activeSkillFilter;
    const textMatches = !query || card.textContent.toLowerCase().includes(query);
    const visible = categoryMatches && textMatches;
    card.hidden = !visible;
    if (visible) visibleCount += 1;
  });
  if (technologyResults) {
    technologyResults.textContent = `${visibleCount} skill${visibleCount === 1 ? "" : "s"} shown`;
  }
}

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeSkillFilter = button.dataset.filter || "all";
    filterButtons.forEach((item) => item.classList.toggle("active", item === button));
    updateSkillResults();
  });
});
technologySearch?.addEventListener("input", updateSkillResults);
updateSkillResults();



/* INTERACTIVE GREEN DIGITAL PARTICLES */


/* GREEN DIGITAL PARTICLES */
(() => {
  const canvas = document.getElementById("particle-canvas");
  if (!canvas) return;

  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const reducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  let particles = [];
  let width = 0;
  let height = 0;
  let animationId;

  const mouse = { x: -1000, y: -1000, active: false };
  const color = "76, 175, 112";
  const connectionDistance = 110;

  function resizeCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;

    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const count = Math.min(
      85,
      Math.max(25, Math.floor((width * height) / 18000))
    );

    particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      radius: Math.random() * 1.5 + 1
    }));
  }

  window.addEventListener("pointermove", (event) => {
    if (event.pointerType === "touch") return;
    mouse.x = event.clientX;
    mouse.y = event.clientY;
    mouse.active = true;
  });

  window.addEventListener("pointerleave", () => {
    mouse.active = false;
  });

  function animate() {
    ctx.clearRect(0, 0, width, height);

    // Soft green glow around the cursor
    if (mouse.active) {
      const glow = ctx.createRadialGradient(
        mouse.x, mouse.y, 0,
        mouse.x, mouse.y, 170
      );

      glow.addColorStop(0, `rgba(${color}, 0.12)`);
      glow.addColorStop(1, `rgba(${color}, 0)`);
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, width, height);
    }

    // Move and draw the particles
    for (const p of particles) {
      if (!reducedMotion) {
        p.x += p.vx;
        p.y += p.vy;

        // Gently push dots away from the cursor
        if (mouse.active) {
          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          const distance = Math.hypot(dx, dy);

          if (distance < 130 && distance > 0) {
            const force = ((130 - distance) / 130) * 0.6;
            p.x += (dx / distance) * force;
            p.y += (dy / distance) * force;
          }
        }

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;
      }

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${color}, 0.85)`;
      ctx.shadowBlur = 8;
      ctx.shadowColor = `rgba(${color}, 0.7)`;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // Connect nearby dots with green lines
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const a = particles[i];
        const b = particles[j];
        const distance = Math.hypot(a.x - b.x, a.y - b.y);

        if (distance < connectionDistance) {
          let opacity =
            (1 - distance / connectionDistance) * 0.22;

          if (mouse.active) {
            const midX = (a.x + b.x) / 2;
            const midY = (a.y + b.y) / 2;
            const nearMouse = Math.hypot(
              midX - mouse.x,
              midY - mouse.y
            );

            if (nearMouse < 130) opacity += 0.2;
          }

          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.strokeStyle =
            `rgba(${color}, ${Math.min(opacity, 0.5)})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
    }

    if (!reducedMotion) {
      animationId = requestAnimationFrame(animate);
    }
  }

  resizeCanvas();
  animate();

  window.addEventListener("resize", () => {
    cancelAnimationFrame(animationId);
    resizeCanvas();
    animate();
  });
})();




// Subtle magnetic movement for buttons; disabled on touch/reduced-motion devices.
if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches && window.matchMedia("(pointer: fine)").matches) {
  document.querySelectorAll(".magnetic-btn").forEach((button) => {
    button.addEventListener("pointermove", (event) => {
      const rect = button.getBoundingClientRect();
      const dx = event.clientX - (rect.left + rect.width / 2);
      const dy = event.clientY - (rect.top + rect.height / 2);
      button.style.transform = `translate(${dx * 0.08}px, ${dy * 0.12}px)`;
    });
    button.addEventListener("pointerleave", () => { button.style.transform = ""; });
  });
}
