// Vercel serverless endpoint for the portfolio AI assistant.
export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed." });
  }
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message || message.length > 1000) {
    return res.status(400).json({ error: "Please send a message up to 1000 characters." });
  }
  const apiKey = process.env.GROQ_API_KEY;
  const model = process.env.GROQ_MODEL || "openai/gpt-oss-20b";
  if (!apiKey) return res.status(500).json({ error: "AI assistant is not configured yet. Add GROQ_API_KEY in Vercel environment variables." });
  try {
    const upstream = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: "You are the portfolio assistant for Tanishka Vashistha. Her listed skills and interests are C++, C, AI, ML, NLP, generative AI, web development, and Python. Answer questions about this portfolio helpfully. Do not invent education, experience, projects, contact details, or achievements that are not provided. If asked, say those details have not been added yet." },
          { role: "user", content: message }
        ],
        temperature: 0.6,
        max_tokens: 700
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || "The AI provider request failed." });
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) return res.status(502).json({ error: "The AI returned an empty response." });
    return res.status(200).json({ reply: reply.trim() });
  } catch (error) {
    return res.status(500).json({ error: "Could not reach the AI service. Please try again." });
  }
}
